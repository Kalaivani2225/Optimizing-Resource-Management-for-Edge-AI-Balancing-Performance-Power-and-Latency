import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np

class QNetwork(nn.Module):
    def __init__(self, state_dim, action_dim, hidden_dim=64, dropout_prob=0.5):
        super(QNetwork, self).__init__()
        self.fc1 = nn.Linear(state_dim, hidden_dim)
        self.ln1 = nn.LayerNorm(hidden_dim)  # Use Layer Normalization
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.ln2 = nn.LayerNorm(hidden_dim)
        self.fc3 = nn.Linear(hidden_dim, hidden_dim)
        self.ln3 = nn.LayerNorm(hidden_dim)
        self.fc4 = nn.Linear(hidden_dim, action_dim)
        self.dropout = nn.Dropout(p=dropout_prob)

    def forward(self, state):
        x = torch.relu(self.ln1(self.fc1(state)))  # Use Layer Normalization
        x = self.dropout(x)
        x = torch.relu(self.ln2(self.fc2(x)))  # Use Layer Normalization
        x = self.dropout(x)
        x = torch.relu(self.ln3(self.fc3(x)))  # Use Layer Normalization
        q_values = self.fc4(x)
        return q_values

class DQNAgent:
    def __init__(self, state_dim, action_dim, hidden_dim=64, lr=0.001, gamma=0.99, epsilon=1.0, epsilon_decay=0.997):
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.hidden_dim = hidden_dim
        self.lr = lr
        self.gamma = gamma
        self.epsilon = epsilon
        self.epsilon_decay = epsilon_decay

        self.q_network = QNetwork(state_dim, action_dim, hidden_dim)
        self.target_network = QNetwork(state_dim, action_dim, hidden_dim)
        self.target_network.load_state_dict(self.q_network.state_dict())
        self.target_network.eval()

        self.optimizer = optim.Adam(self.q_network.parameters(), lr=self.lr)  # Use Adam optimizer
        self.criterion = nn.MSELoss()
        self.loss = None

    def choose_action(self, state):
        if np.random.rand() < self.epsilon:
            return np.random.randint(self.action_dim)
        else:
            with torch.no_grad():
                state_tensor = torch.FloatTensor(state).unsqueeze(0)
                q_values = self.q_network(state_tensor)
                return q_values.argmax(dim=1).item()

    def update(self, state, action, next_state, reward, done):
        state_tensor = torch.FloatTensor(state).unsqueeze(0)
        action_tensor = torch.LongTensor([action]).unsqueeze(0)
        next_state_tensor = torch.FloatTensor(next_state).unsqueeze(0)
        reward_tensor = torch.FloatTensor([reward]).unsqueeze(0)
        done_tensor = torch.FloatTensor([done]).unsqueeze(0)

        q_values = self.q_network(state_tensor)
        q_value = q_values.gather(1, action_tensor)

        next_q_values = self.target_network(next_state_tensor).detach()
        max_next_q_value = next_q_values.max(dim=1)[0]
        expected_q_value = reward_tensor + self.gamma * max_next_q_value * (1 - done_tensor)

        loss = self.criterion(q_value, expected_q_value)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

    def update_target_network(self):
        self.target_network.load_state_dict(self.q_network.state_dict())
