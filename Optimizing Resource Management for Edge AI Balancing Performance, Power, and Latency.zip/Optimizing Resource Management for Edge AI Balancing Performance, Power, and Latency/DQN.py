import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np

# Updated Q-network class using LayerNorm instead of BatchNorm1d
class QNetwork(nn.Module):
    def __init__(self, state_dim, action_dim, hidden_dim=117, dropout_prob=0.3237663580138292):
        super(QNetwork, self).__init__()
        self.fc1 = nn.Linear(state_dim, hidden_dim)
        self.ln1 = nn.LayerNorm(hidden_dim)  # Replace BatchNorm1d with LayerNorm
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.ln2 = nn.LayerNorm(hidden_dim)
        self.fc3 = nn.Linear(hidden_dim, hidden_dim)
        self.ln3 = nn.LayerNorm(hidden_dim)
        self.fc4 = nn.Linear(hidden_dim, action_dim)

        self.dropout = nn.Dropout(p=dropout_prob)



    def forward(self, state):
        # Adding a batch dimension if needed
        if state.dim() == 1:
            state = state.unsqueeze(0)  # Add a batch dimension if it's a single sample

        x = torch.relu(self.ln1(self.fc1(state)))  # Use LayerNorm
        x = self.dropout(x)
        x = torch.relu(self.ln2(self.fc2(x)))
        x = self.dropout(x)
        x = torch.relu(self.ln3(self.fc3(x)))
        q_values = self.fc4(x)
        return q_values


# Updated DQN Agent class with best hyperparameters from Optuna
class DQNAgent:
    def __init__(self, state_dim, action_dim, hidden_dim=117, lr=0.006488854311589868, gamma=0.9105059278134703, epsilon=1.0, epsilon_decay=0.9825145562305004, dropout_prob=0.3237663580138292):
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.hidden_dim = hidden_dim
        self.lr = lr
        self.gamma = gamma
        self.epsilon = epsilon
        self.epsilon_decay = epsilon_decay

        # Initialize Q-network and target network
        self.q_network = QNetwork(state_dim, action_dim, hidden_dim, dropout_prob)
        self.target_network = QNetwork(state_dim, action_dim, hidden_dim, dropout_prob)
        self.update_target_network()  # Initialize target network with Q-network weights
        self.optimizer = optim.Adam(self.q_network.parameters(), lr=self.lr)  # Using Adam optimizer

        # Define the loss function for Q-network updates
        self.criterion = nn.MSELoss()

    def choose_action(self, state):
        # Epsilon-greedy action selection
        if np.random.rand() < self.epsilon:
            return np.random.randint(self.action_dim)  # Random action (exploration)
        else:
            with torch.no_grad():
                state_tensor = torch.FloatTensor(state)
                if state_tensor.dim() == 1:
                    state_tensor = state_tensor.unsqueeze(0)  # Add a batch dimension if needed
                q_values = self.q_network(state_tensor)
                return q_values.argmax().item()  # Action with highest Q-value (exploitation)

    def update(self, state, action, next_state, reward, done):
        state_tensor = torch.FloatTensor(state)
        next_state_tensor = torch.FloatTensor(next_state)
        reward_tensor = torch.FloatTensor([reward])
        done_tensor = torch.FloatTensor([done])

        if state_tensor.dim() == 1:
            state_tensor = state_tensor.unsqueeze(0)  # Add batch dimension if needed
        if next_state_tensor.dim() == 1:
            next_state_tensor = next_state_tensor.unsqueeze(0)

        action_tensor = torch.LongTensor([action]).unsqueeze(0)

        # Compute current Q value
        q_values = self.q_network(state_tensor)
        q_value = q_values.gather(1, action_tensor)

        # Compute the expected Q value
        next_q_values = self.target_network(next_state_tensor).detach()
        max_next_q_value = next_q_values.max(dim=1)[0]
        expected_q_value = reward_tensor + self.gamma * max_next_q_value * (1 - done_tensor)

        # Compute loss and perform backpropagation
        loss = self.criterion(q_value, expected_q_value.unsqueeze(1))
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

        # Update epsilon for exploration-exploitation trade-off
        self.epsilon *= self.epsilon_decay
        self.epsilon = max(0.01, self.epsilon)  # Ensure epsilon does not go below a threshold

    def update_target_network(self):
        # Synchronize target network with Q-network
        self.target_network.load_state_dict(self.q_network.state_dict())



