import os
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from edge_sim_py import *
from DQN import DQNAgent

# Ensure the 'results' directory exists
os.makedirs("results", exist_ok=True)


# Define custom data collection method to track power and resource usage of each server
def custom_collect_method(self) -> dict:
    metrics = {
        "Instance ID": self.id,
        "Power Consumption": self.get_power_consumption(),
        "CPU Usage": self.cpu,
        "Memory Usage": self.memory,
        "Disk Usage": self.disk
    }
    return metrics


# Initialize lists for tracking rewards and power consumption over time
reward_list = []
power_list = []


def my_algorithm(parameters):
    """
    Custom task scheduling algorithm that uses DQN to optimize power consumption.
    """
    total_reward = 0
    total_power = 0

    for service in Service.all():  # Iterate over every service
        if not service.being_provisioned:  # If service needs migration
            state_vector = []
            for edge_server in EdgeServer.all():
                edge_server_cpu = edge_server.cpu
                edge_server_memory = edge_server.memory
                edge_server_disk = edge_server.disk
                power = calculate_power(edge_server_cpu, edge_server_memory, edge_server_disk)
                state_vector.extend([edge_server_cpu, edge_server_memory, edge_server_disk, power])

            state_vector = np.array(state_vector)
            action = agent.choose_action(state_vector)  # Choose action based on state

            # Skip migration if target is the current server
            if EdgeServer.all()[action] == service.server:
                continue

            # Migrate the service
            print(
                f"[STEP {parameters['current_step']}] Migrating {service} From {service.server} to {EdgeServer.all()[action]}")
            service.provision(target_server=EdgeServer.all()[action])

            # Calculate reward and power for new state
            next_state_vector = []
            reward = 0
            power = 0
            for edge_server in EdgeServer.all():
                edge_server_cpu = edge_server.cpu
                edge_server_memory = edge_server.memory
                edge_server_disk = edge_server.disk
                power = calculate_power(edge_server_cpu, edge_server_memory, edge_server_disk)
                next_state_vector.extend([edge_server_cpu, edge_server_memory, edge_server_disk, power])
                reward += 1 / edge_server.get_power_consumption()
                power += edge_server.get_power_consumption()

            next_state_vector = np.array(next_state_vector)
            agent.update(state_vector, action, next_state_vector, reward, False)
            total_reward += reward
            total_power += power

    reward_list.append(total_reward)
    power_list.append(total_power)
    agent.epsilon *= agent.epsilon_decay  # Reduce exploration probability


def calculate_power(cpu, memory, disk):
    """
    Calculate power consumption based on CPU, memory, and disk utilization.
    """
    return (cpu * memory * disk) ** (1 / 3)


# Define stopping criterion for the simulation
def stopping_criterion(model: object):
    return model.schedule.steps == 1000


# Set up and initialize simulator
simulator = Simulator(
    tick_duration=1,
    tick_unit="seconds",
    stopping_criterion=stopping_criterion,
    resource_management_algorithm=my_algorithm,
)

simulator.initialize(input_file=r"E:\pythonProject\EdgeAISIM\sample_dataset1.json")
EdgeServer.collect = custom_collect_method  # Assign the custom collect method
agent = DQNAgent(len(EdgeServer.all()) * 4, len(EdgeServer.all()))  # Initialize DQN agent

# Run the simulation
simulator.run_model()

# Load logs into DataFrame for plotting and analysis
df = pd.DataFrame(simulator.agent_metrics["EdgeServer"])

# =====================
# Power Consumption Comparison Graph
# =====================
fig, ax1 = plt.subplots(figsize=(10, 6))
for edge_server_id in df['Instance ID'].unique():
    edge_server_data = df[df['Instance ID'] == edge_server_id]
    cumulative_power = edge_server_data['Power Consumption'].cumsum()
    ax1.plot(edge_server_data['Time Step'], cumulative_power, label=f"EdgeServer {edge_server_id}")

ax1.plot(list(range(1, len(power_list) + 1)), power_list, linestyle='--', color='red', label="Total Power Consumption")
ax1.set_title("Power Consumption Comparison Over Time")
ax1.set_xlabel("Time Step")
ax1.set_ylabel("Cumulative Power Consumption")
ax1.legend(loc='upper left')
plt.savefig("results/Power_Consumption_Comparison_Graph.png")
plt.show()

# =====================
# Adaptability and Resource Usage Graph
# =====================
fig, axes = plt.subplots(len(df['Instance ID'].unique()), 3, figsize=(15, 4 * len(df['Instance ID'].unique())),
                         sharex=True)
for i, edge_server_id in enumerate(df['Instance ID'].unique()):
    edge_server_data = df[df['Instance ID'] == edge_server_id]
    timesteps = edge_server_data['Time Step']

    # CPU Usage
    axes[i, 0].plot(timesteps, edge_server_data['CPU Usage'], label=f"EdgeServer {edge_server_id} CPU")
    axes[i, 0].set_title(f"CPU Usage - EdgeServer {edge_server_id}")
    axes[i, 0].set_ylabel("CPU (%)")
    axes[i, 0].legend()

    # Memory Usage
    axes[i, 1].plot(timesteps, edge_server_data['Memory Usage'], label=f"EdgeServer {edge_server_id} Memory")
    axes[i, 1].set_title(f"Memory Usage - EdgeServer {edge_server_id}")
    axes[i, 1].set_ylabel("Memory (MB)")
    axes[i, 1].legend()

    # Disk Usage
    axes[i, 2].plot(timesteps, edge_server_data['Disk Usage'], label=f"EdgeServer {edge_server_id} Disk")
    axes[i, 2].set_title(f"Disk Usage - EdgeServer {edge_server_id}")
    axes[i, 2].set_ylabel("Disk (MB)")
    axes[i, 2].legend()

plt.tight_layout()
plt.savefig("results/Adaptability_Resource_Usage_Graph.png")
plt.show()

# =====================
# Comparative Performance Metrics Table/Graph
# =====================
performance_metrics = df.groupby('Instance ID').agg({
    'Power Consumption': ['mean', 'sum'],
    'CPU Usage': 'mean',
    'Memory Usage': 'mean',
    'Disk Usage': 'mean'
}).reset_index()
performance_metrics.columns = [
    'Instance ID', 'Avg Power Consumption', 'Total Power Consumption',
    'Avg CPU Usage', 'Avg Memory Usage', 'Avg Disk Usage'
]
performance_metrics.to_csv("results/Comparative_Performance_Metrics.csv", index=False)

# Plotting comparative performance metrics
fig, ax2 = plt.subplots(figsize=(10, 6))
ax2.bar(performance_metrics['Instance ID'], performance_metrics['Total Power Consumption'], color='blue')
ax2.set_title("Comparative Performance Metrics - Power Consumption")
ax2.set_xlabel("Edge Server ID")
ax2.set_ylabel("Total Power Consumption (units)")
plt.savefig("results/Comparative_Performance_Metrics_BarGraph.png")
plt.show()
