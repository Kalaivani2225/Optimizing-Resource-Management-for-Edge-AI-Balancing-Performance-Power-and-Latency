from edge_sim_py import *
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


# Custom collect method to measure the power consumption of each server
def custom_collect_method(self) -> dict:
    metrics = {
        "Instance ID": self.id,
        "Power Consumption": self.get_power_consumption(),
    }
    return metrics

power_list = []
def my_simple_algorithm(parameters):
    print("\n\n")
    total_power = 0  # Total power consumption

    for service in Service.all():  # Iterate over every service
        # If service needs to be migrated
        if not service.being_provisioned:
            current_server = service.server
            min_power = float('inf')
            target_server = None

            # Find the server with the lowest power consumption
            for edge_server in EdgeServer.all():
                if edge_server != current_server:  # Exclude current server
                    power = edge_server.get_power_consumption()
                    if power < min_power:
                        min_power = power
                        target_server = edge_server

            # If a target server was found, migrate the service
            if target_server:
                print(
                    f"[STEP {parameters['current_step']}] Migrating {service} From {current_server} to {target_server}")
                service.provision(target_server=target_server)

                # Calculate total power after migration
                total_power += min_power  # Add the power consumption of the target server

    power_list.append(total_power)  # Append total power consumption for plotting


def stopping_criterion(model: object):
    return model.schedule.steps == 1000


simulator = Simulator(
    tick_duration=1,
    tick_unit="seconds",
    stopping_criterion=stopping_criterion,
    resource_management_algorithm=my_simple_algorithm,
)

# Loading a sample dataset from GitHub
simulator.initialize(input_file=r"E:\pythonProject\EdgeAISIM\sample_dataset1.json")

# Assigning the custom collect method
EdgeServer.collect = custom_collect_method

# Execute the simulation
simulator.run_model()

# Retrieving logs dataframe for plot
logs = pd.DataFrame(simulator.agent_metrics["EdgeServer"])
print(logs)

df = logs

# Plotting the power consumption
edge_server_ids = df['Instance ID'].unique()
num_subplots = len(edge_server_ids) + 1  # Add 1 for the total power subplot

fig, axes = plt.subplots(num_subplots, 1, figsize=(8, 4 * num_subplots), sharex=True)

# Iterate over each EdgeServer and plot the data
for i, edge_server_id in enumerate(edge_server_ids):
    edge_server_data = df[df['Instance ID'] == edge_server_id]
    timesteps = edge_server_data['Time Step']
    power_consumption = edge_server_data['Power Consumption']

    axes[i].plot(timesteps, power_consumption, label=f"EdgeServer {edge_server_id}")
    axes[i].set_title(f"Power Consumption - EdgeServer {edge_server_id}")
    axes[i].set_ylabel("Power Consumption")
    axes[i].legend()

# Plot the total power consumption across all edge servers
powers_subplot = axes[-1]
power_count_list = list(range(1, len(power_list) + 1))
powers_subplot.plot(power_count_list, power_list, label="Total Power Consumption", linestyle='--', color='red')
powers_subplot.set_title("Total Power Consumption Over Time")
powers_subplot.set_xlabel("Time Step")
powers_subplot.set_ylabel("Total Power")
powers_subplot.legend(loc='upper left')

plt.tight_layout()
plt.subplots_adjust(hspace=0.2)

# Save and display the plot
plt.savefig("simple_migration_power_consumption.png")

# Save logs to a CSV file
logs.to_csv("edge_server_power_consumption_logs.csv", index=False)

print("Simulation completed and results saved.")
