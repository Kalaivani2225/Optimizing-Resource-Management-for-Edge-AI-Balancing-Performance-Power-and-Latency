from edge_sim_py import *
import math
import os
import random
import msgpack
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from DQN import DQNAgent


def custom_collect_method(self) -> dict:  # Custom collect method to measure the power consumption of each server
    metrics = {
        "Instance ID": self.id,
        "Power Consumption": self.get_power_consumption(),
    }
    return metrics


global agent
global reward_list
global reward_count_list
global reward_count

reward_list = list()
power_list = list()  # List to store total power consumption everytime the task scheduling algorithm is used


def my_algorithm(parameters):
    print("\n\n")
    total_reward = 0
    total_power = 0  # We sum the power consumption after migrating each service

    for service in Service.all():  # Iterate over every service

        # If service needs to be migrated
        if not service.being_provisioned:

            # Initialise our state vector, which is the concatenation of the cpu,memory,disk utilisation and current power consumption

            state_vector = []

            for edge_server in EdgeServer.all():
                edge_server_cpu = edge_server.cpu
                edge_server_memory = edge_server.memory
                edge_server_disk = edge_server.disk
                power = (edge_server_cpu * edge_server_memory * edge_server_disk) ** (1 / 3)
                vector = [edge_server_cpu, edge_server_memory, edge_server_disk, power]
                state_vector = state_vector + vector

            # Pass the state vector to out Q - learning agent, and retrieve action
            state_vector = np.array(state_vector)
            action = agent.choose_action(state_vector)

            # To conserve resources, we don't want to migrate back to our host
            if EdgeServer.all()[action] == service.server:
                break

            print(
                f"[STEP {parameters['current_step']}] Migrating {service} From {service.server} to {EdgeServer.all()[action]}")

            # Migrate service to new edgeserver
            service.provision(target_server=EdgeServer.all()[action])

            # Get our next state, after taking action
            next_state_vector = []
            reward = 0
            power = 0

            for edge_server in EdgeServer.all():
                edge_server_cpu = edge_server.cpu
                edge_server_memory = edge_server.memory
                edge_server_disk = edge_server.disk
                power = (edge_server_cpu * edge_server_memory * edge_server_disk) ** (1 / 3)
                vector = [edge_server_cpu, edge_server_memory, edge_server_disk, power]
                next_state_vector = next_state_vector + vector
                reward = reward + 1 / edge_server.get_power_consumption()  # Our reward is the inverse of the edge server's power consumption
                power = power + edge_server.get_power_consumption()  # get the sum of powerconsumption of each edge server

            # Pass the updated state and reward for backporpogation through Q - network
            next_state_vector = np.array(next_state_vector)
            agent.update(state_vector, action, next_state_vector, reward, False)

            # print(reward)
            total_reward += reward
            total_power += power  # Sum our power consumption

    reward_list.append(total_reward)
    power_list.append(total_power)  # Append power consumption to power list for plotting
    agent.epsilon *= agent.epsilon_decay  # Reduce the probability of agent taking random action for exploration


def stopping_criterion(model: object):
    # As EdgeSimPy will halt the simulation whenever this function returns True,
    # its output will be a boolean expression that checks if the current time step is 600
    return model.schedule.steps == 1000


simulator = Simulator(
    tick_duration=1,
    tick_unit="seconds",
    stopping_criterion=stopping_criterion,
    resource_management_algorithm=my_algorithm,
)

# Loading a sample dataset from GitHub
simulator.initialize(input_file=r"E:\pythonProject\EdgeAISIM\sample_dataset1.json")

# Assigning the custom collect method
EdgeServer.collect = custom_collect_method

# Initialise of DQN agent with state and action dimension
# Here, state is the current cpu, memory and disk utilisation of the server, and action space is the choice of edge server
# i.e. the Edge server with the maximum Q- value will be migrated to
agent = DQNAgent(len(EdgeServer.all()) * 4, len(EdgeServer.all()))

# Executing the simulation
simulator.run_model()

# Retrieving logs dataframe for plot
logs = pd.DataFrame(simulator.agent_metrics["EdgeServer"])
print(logs)

df = logs

edge_server_ids = df['Instance ID'].unique()

# Determine the number of subplots based on the number of EdgeServers
num_subplots = len(edge_server_ids) + 1  # Add 1 for the rewards subplot

# Create subplots with the desired layout
fig, axes = plt.subplots(num_subplots, 1, figsize=(
    8, 4 * num_subplots), sharex=True)

# Iterate over each EdgeServer and plot the data in the corresponding subplot
for i, edge_server_id in enumerate(edge_server_ids):
    # Filter the data for the current EdgeServer
    edge_server_data = df[df['Instance ID'] == edge_server_id]

    # Extract the timestep and power consumption values
    timesteps = edge_server_data['Time Step']
    power_consumption = edge_server_data['Power Consumption']

    # Plot the power consumption data for the current EdgeServer in the corresponding subplot
    axes[i].plot(timesteps, power_consumption,
                 label=f"EdgeServer {edge_server_id}")

    # Set the subplot title and labels
    axes[i].set_title(f"Power Consumption - EdgeServer {edge_server_id}")
    axes[i].set_ylabel("Power Consumption")
    axes[i].legend()

# Create a separate subplot for the rewards
# rewards_subplot = axes[-2]
# reward_count_list = list(range(1, len(reward_list) + 1))
# rewards_subplot.plot(reward_count_list, reward_list)
# rewards_subplot.set_title("Rewards")
# rewards_subplot.set_xlabel("Reward Count")
# rewards_subplot.set_ylabel("Reward")

powers_subplot = axes[-1]
power_count_list = list(range(1, len(power_list) + 1))

# Plot the overall total power consumption
powers_subplot.plot(power_count_list, power_list, label="Total Power Consumption", linestyle='--', color='red')

# Plot cumulative power consumption for each Edge Server
for edge_server_id in edge_server_ids:
    # Filter the data for the current EdgeServer
    edge_server_data = df[df['Instance ID'] == edge_server_id]

    # Calculate cumulative power consumption for the server
    cumulative_power = edge_server_data['Power Consumption'].cumsum()

    # Extract the timestep values for x-axis
    timesteps = edge_server_data['Time Step']

    # Plot the cumulative power consumption in the "Total Power" subplot
    powers_subplot.plot(timesteps, cumulative_power, label=f"EdgeServer {edge_server_id} Cumulative", alpha=0.7)

powers_subplot.set_title("Total Power Consumption Over Time")
powers_subplot.set_xlabel("Time Step")
powers_subplot.set_ylabel("Cumulative Power")
powers_subplot.legend(loc='upper left')  # Add a legend to distinguish between servers

# Adjust the spacing between subplots
plt.tight_layout()
plt.subplots_adjust(hspace=0.2)

# Save and display the plot
plt.savefig("myalgoqqqq_migration_power_consumption_final_uncropped.png")

# Calculate and print the total count of total power
logs.to_csv("edge_server_power_consumption_logs.csv", index=False)# Assuming `df` is the DataFrame with Edge Server power data
# Calculate the total power consumption for each row
print(df.head())

